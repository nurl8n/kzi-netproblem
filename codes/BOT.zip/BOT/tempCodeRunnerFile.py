file1 = open("sample1.txt", "a")
        file1.write(trouble + '\n\n')
        file1.close()
        flag2 = True
        if flag2 == True:
            await callback.message.answer("Спасибо, принято. Мы обязательно с вами свяжемся")
            