file1 = open("sample1.txt", "a")
str1 = "mal"
file1.write(str1)
file1.close()