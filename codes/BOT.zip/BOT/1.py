from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.utils import executor
import os
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

# bot = Bot(token = '5465401291:AAFodiuV4N6P-SaAyRM0PG2YDwHO5PygVNo')
bot = Bot(token = '')
dp = Dispatcher(bot)

# ID = None
# answ = dict()

#кнопки ссылка
urlkb = InlineKeyboardMarkup(row_width = 2)
urlButton = InlineKeyboardButton(text = "Ссылка1", url = 'https://www.kzibank.kz/')
urlButton2 = InlineKeyboardButton(text = "Ссылка2", url = 'https://www.kzibank.kz/')

x = [InlineKeyboardButton(text = 'Ссылка3', url = 'wsp.kbtu.kz'), InlineKeyboardButton(text = 'Ссылка4', url = 'wsp.kbtu.kz'), 
    InlineKeyboardButton(text = 'Ссылка5', url = 'wsp.kbtu.kz')]

#urlkb.add(urlButton, urlButton2).row(*x)
urlkb.add(urlButton, urlButton2).row(*x).insert(InlineKeyboardButton(text = 'Ссылка6', url = 'wsp.kbtu.kz'))

@dp.message_handler(commands = 'ссылки')
async def url_command(message : types.Message):
    await message.answer('Ссылочки: ', reply_markup = urlkb)

inkb = InlineKeyboardMarkup(row_width = 1).add(InlineKeyboardButton(text = 'Нажми меня', callback_data = 'www'))

@dp.message_handler(commands = 'test')
async def test_commands(message : types.Message):
    await message.answer('Инлайн кнопка', reply_markup = inkb)

@dp.callback_query_handler(text = 'www')
async def www_call(callback : types.CallbackQuery):
    # await callback.answer('Нажата инлайн кнопка')
    # await callback.answer()
    await callback.message.answer('Нажата инлайн кнопка')
    # нужно подтвердить OK
    await callback.answer('Нажата инлайн кнопка', show_alert = True)
 
# lkb = InlineKeyboardMarkup(row_width = 1).add(InlineKeyboardButton(text = 'Like', callback_data = 'like_1'),
#                                             InlineKeyboardButton(text = 'Не Like', callback_data = 'like_-1'))
# @dp.message_handler(commands = 'like')
# async def like_commands(message : types.Message):
#     await message.answer('KZI???', reply_markup = lkb)
# @dp.callback_query_handler(Text(startswith = 'like_'))
# async def www_call(callback : types.CallbackQuery):
#     res = int(callback.data.split('_')[1])
#     if f'{callback.from_user.id}' not in answ:
#         answ[f'{callback.from_user.id}'] = res
#         await callback.answer('Вы проголосовали')
#     else:
#         await callback.answer('Вы уже проголосовали', show_alert = True)


    


executor.start_polling(dp, skip_updates = True)
