from email.message import Message
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.utils import executor
import os
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

global flag, your_str, d, flag2, trouble
flag = False
your_str = ''
d = 0
flag2 = False
trouble = ''

bot = Bot(token = '5465401291:AAFodiuV4N6P-SaAyRM0PG2YDwHO5PygVNo')
dp = Dispatcher(bot)

mainn = InlineKeyboardMarkup(row_width = 2)
urlButton = InlineKeyboardButton(text = ' Branches ', callback_data = '1')
urlButton2 = InlineKeyboardButton(text = ' Support Service ', callback_data = '2')
urlButton3 = InlineKeyboardButton(text = ' Personal Account ', url = 'https://ibank.kzibank.kz/ibank/LoginNewFiz.aspx ')
urlButton4 = InlineKeyboardButton(text = ' Business Account ', url = 'https://ibank.kzibank.kz/ibank/LoginNew.aspx')
urlButton5 = InlineKeyboardButton(text = ' Calculate a loan ', callback_data = '3')
urlButton6 = InlineKeyboardButton(text = ' Leave message to bank ', callback_data = '4')

mainn.add(urlButton, urlButton2, urlButton3, urlButton4, urlButton5, urlButton6)

@dp.message_handler(commands = 'commands')
async def url_command(message : types.Message):
    await message.answer('Functions: ', reply_markup = mainn)

@dp.callback_query_handler(text = '1')
async def func1(callback : types.CallbackQuery):
    await callback.message.answer('Branches: 7 \n Cities: 6')
    await callback.message.answer('Almaty city: 2 \n*) 132 Klochkov Str. \n*) 59 Haji Mukan Str.')
    await callback.message.answer('Aqtau city: 1 \n *) 17th microdistrict, apt.39, 1st floor, Zodiac Business centеer.')
    await callback.message.answer('Atyrau city: 1 \n *) Baktigerey Kulmanov Str.')
    await callback.message.answer('Nur Sultan city: 1 \n *) 12/1 Kunaev Str.')
    await callback.message.answer('Qaraghandy city: 1 \n *) 20 Abdirov str.')
    await callback.message.answer('Shymkent city: 1 \n *) 59 Kunaev Str.')
    await callback.answer('Список филиалов был выслан', show_alert = True)

@dp.callback_query_handler(text = '2')
async def func2(callback : types.CallbackQuery):
    await callback.message.answer('Support service: \n\n Almaty city: +7 (727) 250 6080 \n Aqtau city: +7 (729) 220 4933 \n Atyrau city: +7 (712) 276 0199 \n Nur Sultan city: +7 (717) 247 5626 \n Qaraghandy city: +7 (7212) 98 30 01 \n Shymkent city: +7 (725) 299 9900')
    await callback.answer('Список службы поддержки по городам был выслан', show_alert = True)

@dp.callback_query_handler(text = '3')
async def func3(callback : types.CallbackQuery):
    # default percent is 5% I guess, might be some logics like if 12 months > then more percentage and so on
    await callback.message.answer('Напишите пожалуйста через пробел в одну линию: \nСумма которую вы хотите получить? \nНа сколько месяцев хотели бы получить кредит?\nПример: 1000000 3')
    @dp.message_handler(content_types=["text"])
    async def handle_text(message):
        print(message)
        your_str = message.text
        print(your_str)
        a = your_str.split(' ')
        b = int(a[0])
        c = int(a[1])
        d = b * (1.05**c)
        flag = True
        if flag == True:
            await callback.message.answer("Approximately: " + str(int(d)) + " KZT")
            
        
@dp.callback_query_handler(text = '4')
async def func4(callback : types.CallbackQuery):
    await callback.message.answer('В случае если у вас возникли дополнительные вопросы, напишите своё имя, номер телефона и ситуацию одним сообщением. Мы обязательно с вами свяжемся.')
    @dp.message_handler(content_types=["text"])
    async def handle_text(message):
        print(message)
        trouble = message.text
        print(trouble)
        file1 = open("sample1.txt", "a")
        file1.write(trouble + '\n\n')
        file1.close()
        flag2 = True
        if flag2 == True:
            await callback.message.answer("Спасибо, принято. Мы обязательно с вами свяжемся")
            
     
#await bot.send_message(828861097, 'reply')
    
executor.start_polling(dp, skip_updates = True)




